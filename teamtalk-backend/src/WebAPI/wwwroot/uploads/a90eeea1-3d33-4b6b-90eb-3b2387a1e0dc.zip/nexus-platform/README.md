# Nexus — Enterprise Collaboration Platform

Full-stack enterprise collaboration platform (Slack/Teams alternative) with .NET 8 backend and React frontend.

## Architecture

```
nexus-platform/
├── nexus-backend/       # .NET 8 Clean Architecture API
│   ├── src/Domain/      # Entities, Enums, Interfaces
│   ├── src/Application/ # Services, DTOs, Validators
│   ├── src/Infrastructure/ # EF Core, Repos, JWT
│   ├── src/WebAPI/      # Controllers, SignalR Hub
│   ├── docker-compose.yml
│   └── Dockerfile
│
└── nexus-frontend/      # React + TypeScript + Vite
    └── src/
        ├── features/    # Auth, Chat, Teams, Notifications
        ├── components/  # UI + Shared components
        ├── store/       # Redux Toolkit slices
        ├── services/    # Axios + SignalR clients
        └── layouts/     # Auth + Dashboard layouts
```

## Quick Start

### 1. Start Backend
```bash
cd nexus-backend
docker-compose up -d
```
Backend: http://localhost:5001  |  Swagger: http://localhost:5001/swagger

### 2. Start Frontend
```bash
cd nexus-frontend
npm install
npm run dev
```
Frontend: http://localhost:3000

### 3. Login
```
Email:    sarah@company.com
Password: password123
```

## Features
- JWT authentication with refresh tokens
- Real-time messaging via SignalR
- Team & channel management (CRUD)
- Role-based access (Admin, Manager, Employee)
- Notification system
- File uploads
- Dark/Light mode
- Admin dashboard with charts
- PostgreSQL database with EF Core
- Docker support
