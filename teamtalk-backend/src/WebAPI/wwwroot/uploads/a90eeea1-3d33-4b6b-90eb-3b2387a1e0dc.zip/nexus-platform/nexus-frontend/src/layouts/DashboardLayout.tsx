import React, { useState, useEffect } from 'react';
import { Outlet, useNavigate, useLocation } from 'react-router-dom';
import {
  Hash, Lock, Bell, Search, Sun, Moon, LogOut, Home, MessageSquare,
  Activity, BarChart3, ChevronDown, ChevronRight, Layers,
} from 'lucide-react';
import { useAppSelector, useAppDispatch, useAuth, useTheme, useNotifications } from '@/hooks';
import { logoutUser } from '@/store/slices/authSlice';
import { fetchTeams, fetchTeamChannels } from '@/store/slices/teamSlice';
import { setActiveChannel } from '@/store/slices/chatSlice';
import { fetchNotifications, markAllAsReadApi } from '@/store/slices/notificationSlice';
import { Avatar, Badge, Button, Dropdown } from '@/components/ui';
import { SidebarItem } from '@/components/shared';
import { formatTime, cn } from '@/utils';

// ═══════════════════════════════════════════════════════════
// SIDEBAR
// ═══════════════════════════════════════════════════════════
const Sidebar: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const dispatch = useAppDispatch();
  const { user } = useAuth();
  const teams = useAppSelector((s) => s.teams.teams);
  const channels = useAppSelector((s) => s.teams.channels);
  const activeChannel = useAppSelector((s) => s.chat.activeChannel);
  const [expandedTeams, setExpandedTeams] = useState<Record<string, boolean>>({});
  const [searchTerm, setSearchTerm] = useState('');

  // Fetch teams on mount
  useEffect(() => {
    dispatch(fetchTeams());
    dispatch(fetchNotifications());
  }, [dispatch]);

  // Fetch channels for each team
  useEffect(() => {
    teams.forEach((team) => {
      dispatch(fetchTeamChannels(team.id));
      // Auto-expand first team
      if (teams.length > 0) {
        setExpandedTeams((prev) => ({ ...prev, [teams[0].id]: true }));
      }
    });
  }, [teams, dispatch]);

  const toggleTeam = (id: string) => setExpandedTeams((p) => ({ ...p, [id]: !p[id] }));

  const filteredChannels = channels.filter((c) =>
    c.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const navItems = [
    { icon: <Home size={16} />, label: 'Home', path: '/dashboard' },
    { icon: <MessageSquare size={16} />, label: 'Direct Messages', path: '/dashboard/messages' },
    { icon: <Activity size={16} />, label: 'Activity', path: '/dashboard/activity' },
    ...(user?.role === 'admin' ? [{ icon: <BarChart3 size={16} />, label: 'Admin', path: '/dashboard/admin' }] : []),
  ];

  const handleChannelClick = (channelId: string) => {
    dispatch(setActiveChannel(channelId));
    navigate(`/dashboard/chat/${channelId}`);
  };

  const handleLogout = () => {
    dispatch(logoutUser());
    navigate('/login');
  };

  return (
    <aside className="w-[260px] bg-white dark:bg-surface-900 border-r border-subtle flex flex-col h-screen flex-shrink-0">
      <div className="px-4 py-3.5 border-b border-subtle flex items-center gap-3">
        <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
          style={{ background: 'linear-gradient(135deg, #6247ea, #8b5cf6)' }}>
          <Layers size={18} className="text-white" />
        </div>
        <div className="min-w-0">
          <div className="font-bold text-sm text-gray-900 dark:text-gray-100 font-display truncate">Nexus</div>
          <div className="text-[11px] text-gray-400 dark:text-gray-600">Enterprise workspace</div>
        </div>
      </div>

      <div className="px-3 py-2.5">
        <div className="flex items-center gap-2 bg-surface-100 dark:bg-surface-850 rounded-lg px-3 py-1.5">
          <Search size={13} className="text-gray-400" />
          <input placeholder="Search channels..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)}
            className="bg-transparent border-none outline-none text-xs text-gray-900 dark:text-gray-100 w-full placeholder:text-gray-400 dark:placeholder:text-gray-600 font-body" />
        </div>
      </div>

      <div className="px-2 space-y-0.5">
        {navItems.map((item) => (
          <SidebarItem key={item.path} icon={item.icon} label={item.label}
            isActive={location.pathname === item.path} onClick={() => navigate(item.path)} />
        ))}
      </div>

      <div className="flex-1 overflow-y-auto scrollbar-thin px-2 py-3 space-y-1">
        {teams.map((team) => {
          const teamChannels = filteredChannels.filter((c) => c.teamId === team.id);
          if (searchTerm && teamChannels.length === 0) return null;
          return (
            <div key={team.id}>
              <button onClick={() => toggleTeam(team.id)}
                className="w-full flex items-center gap-1.5 px-2 py-1.5 text-[11px] font-bold uppercase tracking-wide text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:hover:text-gray-400 transition-colors">
                {expandedTeams[team.id] ? <ChevronDown size={11} /> : <ChevronRight size={11} />}
                <span>{team.icon}</span>
                <span>{team.name}</span>
              </button>
              {expandedTeams[team.id] && teamChannels.map((ch) => {
                const isActive = activeChannel === ch.id && location.pathname.startsWith('/dashboard/chat');
                return (
                  <button key={ch.id} onClick={() => handleChannelClick(ch.id)}
                    className={cn(
                      'w-full flex items-center gap-2 pl-8 pr-3 py-1.5 rounded-r-lg mr-2 text-[13px] transition-all duration-100',
                      isActive ? 'bg-brand-500/10 text-brand-500 dark:text-brand-300 font-semibold'
                        : 'text-gray-500 dark:text-gray-400 hover:bg-surface-100 dark:hover:bg-surface-800/60'
                    )}>
                    {ch.isPrivate ? <Lock size={13} /> : <Hash size={13} />}
                    <span className="truncate">{ch.name}</span>
                  </button>
                );
              })}
            </div>
          );
        })}
      </div>

      <div className="px-3 py-3 border-t border-subtle flex items-center gap-2.5">
        {user && <Avatar user={{ id: user.id, name: user.name, status: user.status as any, avatarUrl: user.avatarUrl }} size="sm" />}
        <div className="flex-1 min-w-0">
          <div className="text-[13px] font-semibold text-gray-900 dark:text-gray-100 truncate">{user?.name}</div>
          <div className="text-[11px] text-gray-400 dark:text-gray-600 capitalize">{user?.role}</div>
        </div>
        <button onClick={handleLogout} className="p-1.5 rounded-lg hover:bg-surface-100 dark:hover:bg-surface-800 text-gray-400 transition-colors">
          <LogOut size={15} />
        </button>
      </div>
    </aside>
  );
};

// ═══════════════════════════════════════════════════════════
// NAVBAR
// ═══════════════════════════════════════════════════════════
const Navbar: React.FC = () => {
  const { isDark, toggle: toggleTheme } = useTheme();
  const { notifications, unreadCount } = useNotifications();
  const dispatch = useAppDispatch();
  const activeChannel = useAppSelector((s) => s.chat.activeChannel);
  const channels = useAppSelector((s) => s.teams.channels);
  const channel = channels.find((c) => c.id === activeChannel);
  const location = useLocation();
  const [showNotifs, setShowNotifs] = useState(false);

  const getTitle = () => {
    if (location.pathname.startsWith('/dashboard/chat') && channel) return null;
    if (location.pathname === '/dashboard/admin') return 'Admin Dashboard';
    if (location.pathname === '/dashboard/activity') return 'Activity';
    if (location.pathname === '/dashboard/teams') return 'Teams';
    return 'Home';
  };
  const title = getTitle();

  return (
    <header className="h-14 bg-white dark:bg-surface-900 border-b border-subtle flex items-center px-5 gap-3 flex-shrink-0">
      <div className="flex-1 flex items-center gap-2.5">
        {title ? (
          <h1 className="font-bold text-[15px] text-gray-900 dark:text-gray-100 font-display">{title}</h1>
        ) : channel ? (
          <>
            <div className="flex items-center gap-1.5 font-bold text-[15px] text-gray-900 dark:text-gray-100 font-display">
              {channel.isPrivate ? <Lock size={15} /> : <Hash size={15} />}
              {channel.name}
            </div>
            <span className="text-xs text-gray-400 dark:text-gray-600 hidden md:inline">{channel.description}</span>
          </>
        ) : null}
      </div>
      <div className="flex items-center gap-1">
        <Button variant="ghost" size="sm" onClick={toggleTheme}>
          {isDark ? <Sun size={16} /> : <Moon size={16} />}
        </Button>
        <div className="relative">
          <button onClick={() => setShowNotifs(!showNotifs)}
            className="relative p-2 rounded-lg hover:bg-surface-100 dark:hover:bg-surface-800 transition-colors">
            <Bell size={16} className="text-gray-500 dark:text-gray-400" />
            {unreadCount > 0 && <Badge count={unreadCount} className="absolute -top-0.5 -right-0.5" />}
          </button>
          <Dropdown isOpen={showNotifs} onClose={() => setShowNotifs(false)} className="w-[340px]">
            <div className="px-4 py-3 border-b border-subtle flex justify-between items-center">
              <span className="font-bold text-sm text-gray-900 dark:text-gray-100 font-display">Notifications</span>
              {unreadCount > 0 && (
                <button onClick={() => dispatch(markAllAsReadApi())}
                  className="text-xs text-brand-500 font-semibold hover:underline">Mark all read</button>
              )}
            </div>
            <div className="max-h-72 overflow-y-auto scrollbar-thin">
              {notifications.map((n) => (
                <div key={n.id}
                  className={cn('px-4 py-3 border-b border-subtle/50 cursor-pointer transition-colors',
                    'hover:bg-surface-50 dark:hover:bg-surface-800/40',
                    !n.read && 'bg-brand-50/50 dark:bg-brand-500/5')}>
                  <p className="text-[13px] text-gray-800 dark:text-gray-200">{n.content}</p>
                  <p className="text-[11px] text-gray-400 mt-1">{formatTime(n.timestamp)}</p>
                </div>
              ))}
              {notifications.length === 0 && (
                <p className="px-4 py-8 text-center text-sm text-gray-400">No notifications</p>
              )}
            </div>
          </Dropdown>
        </div>
      </div>
    </header>
  );
};

// ═══════════════════════════════════════════════════════════
// DASHBOARD LAYOUT
// ═══════════════════════════════════════════════════════════
export const DashboardLayout: React.FC = () => {
  return (
    <div className="flex h-screen overflow-hidden bg-surface-50 dark:bg-surface-950">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Navbar />
        <main className="flex-1 overflow-hidden">
          <Outlet />
        </main>
      </div>
    </div>
  );
};
