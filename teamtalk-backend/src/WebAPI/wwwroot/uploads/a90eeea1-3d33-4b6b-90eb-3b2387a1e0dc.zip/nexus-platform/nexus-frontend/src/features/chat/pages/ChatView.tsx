import React, { useEffect, useRef, useState } from 'react';
import { useParams } from 'react-router-dom';
import { Send, Paperclip, AtSign, Smile, Hash, Lock, MessageSquare, Users } from 'lucide-react';
import { useAppDispatch, useAppSelector, useAuth, useSignalR } from '@/hooks';
import { fetchMessages, sendMessage, setActiveChannel, editMessage, deleteMessage } from '@/store/slices/chatSlice';
import { MOCK_CHANNELS } from '@/store/slices/teamSlice';
import { MessageBubble } from '@/components/shared';
import { Avatar, Loader } from '@/components/ui';
import { cn } from '@/utils';
import type { User } from '@/types';

// Mock user data - in production, this comes from a users slice
const USERS: Record<string, User> = {
  u1: { id: 'u1', name: 'Sarah Chen', email: 'sarah@company.com', role: 'admin', status: 'online', title: 'Engineering Lead', createdAt: '' },
  u2: { id: 'u2', name: 'Marcus Johnson', email: 'marcus@company.com', role: 'member', status: 'online', title: 'Senior Developer', createdAt: '' },
  u3: { id: 'u3', name: 'Elena Rodriguez', email: 'elena@company.com', role: 'member', status: 'away', title: 'Product Designer', createdAt: '' },
  u4: { id: 'u4', name: 'David Park', email: 'david@company.com', role: 'member', status: 'offline', title: 'Backend Engineer', createdAt: '' },
  u5: { id: 'u5', name: 'Aisha Patel', email: 'aisha@company.com', role: 'moderator', status: 'online', title: 'Project Manager', createdAt: '' },
  u6: { id: 'u6', name: 'James Wilson', email: 'james@company.com', role: 'member', status: 'dnd', title: 'QA Engineer', createdAt: '' },
  u7: { id: 'u7', name: 'Lisa Thompson', email: 'lisa@company.com', role: 'member', status: 'online', title: 'Frontend Developer', createdAt: '' },
  u8: { id: 'u8', name: 'Omar Hassan', email: 'omar@company.com', role: 'member', status: 'away', title: 'DevOps Engineer', createdAt: '' },
};

// ── Typing Indicator ─────────────────────────────────────────
const TypingIndicator: React.FC = () => (
  <div className="flex items-center gap-2 px-5 py-1">
    <div className="flex gap-1">
      {[0, 1, 2].map((i) => (
        <div
          key={i}
          className="w-1.5 h-1.5 rounded-full bg-gray-400 dark:bg-gray-600"
          style={{ animation: `typing 1.4s ${i * 0.2}s infinite ease-in-out` }}
        />
      ))}
    </div>
    <span className="text-xs text-gray-400 dark:text-gray-600">Marcus is typing...</span>
  </div>
);

// ── Right Panel (Members) ────────────────────────────────────
const MembersPanel: React.FC<{ channelId: string }> = ({ channelId }) => {
  const channel = MOCK_CHANNELS.find((c) => c.id === channelId);
  const teams = useAppSelector((s) => s.teams.teams);
  const team = teams.find((t) => t.id === channel?.teamId);
  const members = team ? team.members.map((id) => USERS[id]).filter(Boolean) : [];
  const online = members.filter((m) => m.status === 'online');
  const offline = members.filter((m) => m.status !== 'online');

  return (
    <aside className="w-[240px] bg-white dark:bg-surface-900 border-l border-subtle flex flex-col h-full flex-shrink-0">
      <div className="px-4 py-3.5 border-b border-subtle">
        <h3 className="font-bold text-sm text-gray-900 dark:text-gray-100 font-display">
          Members — {members.length}
        </h3>
      </div>
      <div className="flex-1 overflow-y-auto scrollbar-thin py-2">
        {online.length > 0 && (
          <>
            <div className="px-4 py-2 text-[11px] font-bold uppercase tracking-wide text-gray-400 dark:text-gray-600">
              Online — {online.length}
            </div>
            {online.map((u) => (
              <div key={u.id} className="flex items-center gap-2.5 px-4 py-1.5 cursor-pointer hover:bg-surface-50 dark:hover:bg-surface-800/40 transition-colors">
                <Avatar user={u} size="sm" />
                <div className="min-w-0">
                  <div className="text-[13px] font-medium text-gray-900 dark:text-gray-100 truncate">{u.name}</div>
                  <div className="text-[11px] text-gray-400 dark:text-gray-600 truncate">{u.title}</div>
                </div>
              </div>
            ))}
          </>
        )}
        {offline.length > 0 && (
          <>
            <div className="px-4 py-2 mt-2 text-[11px] font-bold uppercase tracking-wide text-gray-400 dark:text-gray-600">
              Offline — {offline.length}
            </div>
            {offline.map((u) => (
              <div key={u.id} className="flex items-center gap-2.5 px-4 py-1.5 opacity-50">
                <Avatar user={u} size="sm" />
                <div className="min-w-0">
                  <div className="text-[13px] font-medium text-gray-900 dark:text-gray-100 truncate">{u.name}</div>
                  <div className="text-[11px] text-gray-400 truncate">{u.title}</div>
                </div>
              </div>
            ))}
          </>
        )}
      </div>
    </aside>
  );
};

// ═══════════════════════════════════════════════════════════
// CHAT VIEW PAGE
// ═══════════════════════════════════════════════════════════
const ChatView: React.FC = () => {
  const { channelId } = useParams<{ channelId: string }>();
  const dispatch = useAppDispatch();
  const { user } = useAuth();
  const messages = useAppSelector((s) => (channelId ? s.chat.messages[channelId] : undefined));
  const isLoading = useAppSelector((s) => s.chat.isLoading);
  const [messageText, setMessageText] = useState('');
  const [showTyping, setShowTyping] = useState(false);
  const [showMembers, setShowMembers] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { joinChannel, leaveChannel } = useSignalR();

  const channel = MOCK_CHANNELS.find((c) => c.id === channelId);

  useEffect(() => {
    if (channelId) {
      dispatch(setActiveChannel(channelId));
      dispatch(fetchMessages({ channelId }));
      joinChannel(channelId);
      return () => {
        leaveChannel(channelId);
      };
    }
  }, [channelId, dispatch, joinChannel, leaveChannel]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = () => {
    if (!messageText.trim() || !channelId) return;
    dispatch(sendMessage({ channelId, content: messageText }));
    setMessageText('');
    setShowTyping(true);
    setTimeout(() => setShowTyping(false), 2500);
  };

  const handleEdit = (messageId: string, content: string) => {
    if (channelId) dispatch(editMessage({ channelId, messageId, content }));
  };

  const handleDelete = (messageId: string) => {
    if (channelId) dispatch(deleteMessage({ channelId, messageId }));
  };

  // Empty state
  if (!channelId || !channel) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="text-center">
          <MessageSquare size={48} className="mx-auto mb-4 text-gray-300 dark:text-gray-700" />
          <p className="text-gray-400 dark:text-gray-600 font-medium">Select a channel to start chatting</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-full">
      <div className="flex-1 flex flex-col h-full">
        {/* Messages area */}
        <div className="flex-1 overflow-y-auto scrollbar-thin">
          {/* Channel welcome */}
          <div className="px-5 pt-5 pb-6 border-b border-subtle/50 mb-2">
            <div className="w-12 h-12 rounded-2xl bg-brand-50 dark:bg-brand-500/10 flex items-center justify-center mb-3">
              {channel.isPrivate ? (
                <Lock size={22} className="text-brand-500" />
              ) : (
                <Hash size={22} className="text-brand-500" />
              )}
            </div>
            <h2 className="text-xl font-black text-gray-900 dark:text-gray-100 font-display mb-1">
              Welcome to #{channel.name}
            </h2>
            <p className="text-sm text-gray-500 dark:text-gray-400">
              {channel.description}. This is the start of the <strong className="text-gray-700 dark:text-gray-300">#{channel.name}</strong> channel.
            </p>
          </div>

          {isLoading ? (
            <Loader />
          ) : (
            messages?.map((msg) => (
              <MessageBubble
                key={msg.id}
                message={msg}
                user={USERS[msg.userId] || { id: msg.userId, name: 'Unknown', email: '', role: 'member', status: 'offline', title: '', createdAt: '' }}
                isOwn={msg.userId === user?.id}
                onEdit={handleEdit}
                onDelete={handleDelete}
              />
            ))
          )}
          {showTyping && <TypingIndicator />}
          <div ref={messagesEndRef} />
        </div>

        {/* Input area */}
        <div className="p-4 border-t border-subtle">
          <div className="flex items-end gap-2 bg-surface-100 dark:bg-surface-850 rounded-xl px-3.5 py-2.5 border border-subtle focus-within:border-brand-500/40 transition-colors">
            <button className="p-1 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors flex-shrink-0 mb-0.5">
              <Paperclip size={18} />
            </button>
            <input
              value={messageText}
              onChange={(e) => setMessageText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSend();
                }
              }}
              placeholder={`Message #${channel.name}`}
              className="flex-1 bg-transparent border-none outline-none text-sm text-gray-900 dark:text-gray-100 placeholder:text-gray-400 dark:placeholder:text-gray-600 font-body"
            />
            <div className="flex items-center gap-1 flex-shrink-0 mb-0.5">
              <button className="p-1 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors">
                <AtSign size={18} />
              </button>
              <button className="p-1 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors">
                <Smile size={18} />
              </button>
              <button
                onClick={handleSend}
                className={cn(
                  'w-8 h-8 rounded-lg flex items-center justify-center transition-all',
                  messageText.trim()
                    ? 'bg-brand-500 hover:bg-brand-600 text-white'
                    : 'bg-surface-200 dark:bg-surface-800 text-gray-400'
                )}
              >
                <Send size={14} />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Members panel */}
      {showMembers && <MembersPanel channelId={channelId} />}
    </div>
  );
};

export default ChatView;
