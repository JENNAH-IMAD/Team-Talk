import React from 'react';
import { useNavigate } from 'react-router-dom';
import { MessageSquare, Users, Hash, Bell, ChevronRight, Lock } from 'lucide-react';
import { useAuth, useAppSelector, useAppDispatch } from '@/hooks';
import { setActiveChannel } from '@/store/slices/chatSlice';
import { MOCK_CHANNELS } from '@/store/slices/teamSlice';
import { getGreeting } from '@/utils';

const HomePage: React.FC = () => {
  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  const { user } = useAuth();
  const teams = useAppSelector((s) => s.teams.teams);

  const quickActions = [
    { icon: MessageSquare, label: 'New Message', color: '#6247ea', onClick: () => {} },
    { icon: Users, label: 'Create Team', color: '#10b981', onClick: () => navigate('/dashboard/teams') },
    { icon: Hash, label: 'Browse Channels', color: '#3b82f6', onClick: () => {} },
    { icon: Bell, label: 'Notifications', color: '#ef4444', onClick: () => {} },
  ];

  const handleChannelClick = (channelId: string) => {
    dispatch(setActiveChannel(channelId));
    navigate(`/dashboard/chat/${channelId}`);
  };

  return (
    <div className="flex-1 overflow-y-auto p-8">
      <div className="max-w-2xl">
        {/* Greeting */}
        <h1 className="text-2xl font-black text-gray-900 dark:text-gray-100 font-display tracking-tight mb-1">
          {getGreeting()}, {user?.name.split(' ')[0]}
        </h1>
        <p className="text-sm text-gray-500 dark:text-gray-400 mb-8">
          Here's what's happening in your workspace today.
        </p>

        {/* Quick actions */}
        <div className="grid grid-cols-4 gap-3 mb-8">
          {quickActions.map((action) => (
            <button
              key={action.label}
              onClick={action.onClick}
              className="bg-white dark:bg-surface-900 border border-subtle rounded-xl p-4 text-center hover:shadow-sm transition-all group"
            >
              <div
                className="w-10 h-10 rounded-xl flex items-center justify-center mx-auto mb-2.5 transition-transform group-hover:scale-110"
                style={{ backgroundColor: action.color + '12' }}
              >
                <action.icon size={18} style={{ color: action.color }} />
              </div>
              <div className="text-xs font-semibold text-gray-700 dark:text-gray-300">{action.label}</div>
            </button>
          ))}
        </div>

        {/* Recent channels */}
        <h3 className="font-bold text-sm text-gray-900 dark:text-gray-100 font-display mb-3">Recent Channels</h3>
        <div className="space-y-1.5 mb-8">
          {MOCK_CHANNELS.slice(0, 4).map((ch) => {
            const team = teams.find((t) => t.id === ch.teamId);
            return (
              <button
                key={ch.id}
                onClick={() => handleChannelClick(ch.id)}
                className="w-full flex items-center gap-3 px-4 py-3 bg-white dark:bg-surface-900 border border-subtle rounded-xl hover:shadow-sm transition-all text-left"
              >
                <div className="w-9 h-9 rounded-lg bg-brand-50 dark:bg-brand-500/10 flex items-center justify-center flex-shrink-0">
                  {ch.isPrivate ? <Lock size={15} className="text-brand-500" /> : <Hash size={15} className="text-brand-500" />}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-semibold text-gray-900 dark:text-gray-100">{ch.name}</div>
                  <div className="text-xs text-gray-400 dark:text-gray-600 truncate">{team?.name} · {ch.description}</div>
                </div>
                <ChevronRight size={15} className="text-gray-300 dark:text-gray-700" />
              </button>
            );
          })}
        </div>

        {/* Teams */}
        <h3 className="font-bold text-sm text-gray-900 dark:text-gray-100 font-display mb-3">Your Teams</h3>
        <div className="grid grid-cols-3 gap-3">
          {teams.map((team) => (
            <button
              key={team.id}
              onClick={() => navigate('/dashboard/teams')}
              className="bg-white dark:bg-surface-900 border border-subtle rounded-xl p-4 text-left hover:shadow-sm transition-all"
            >
              <div className="text-2xl mb-2">{team.icon}</div>
              <div className="text-sm font-bold text-gray-900 dark:text-gray-100 mb-0.5">{team.name}</div>
              <div className="text-xs text-gray-400">{team.members.length} members</div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default HomePage;
