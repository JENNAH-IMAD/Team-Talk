import React from 'react';
import { Users, Layers, MessageSquare, Activity } from 'lucide-react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, AreaChart, Area,
} from 'recharts';
import { Avatar } from '@/components/ui';
import type { User } from '@/types';

// ── Mock Data ────────────────────────────────────────────────
const STATS = [
  { label: 'Total Users', value: '1,247', change: '+12%', icon: Users, color: '#6247ea' },
  { label: 'Total Teams', value: '86', change: '+5%', icon: Layers, color: '#10b981' },
  { label: 'Messages Today', value: '8,432', change: '+23%', icon: MessageSquare, color: '#3b82f6' },
  { label: 'Active Now', value: '342', change: '+8%', icon: Activity, color: '#ef4444' },
];

const ACTIVITY_DATA = [
  { day: 'Mon', messages: 145 },
  { day: 'Tue', messages: 230 },
  { day: 'Wed', messages: 198 },
  { day: 'Thu', messages: 310 },
  { day: 'Fri', messages: 275 },
  { day: 'Sat', messages: 89 },
  { day: 'Sun', messages: 56 },
];

const ROLE_DATA = [
  { name: 'Members', value: 65, color: '#6247ea' },
  { name: 'Moderators', value: 20, color: '#10b981' },
  { name: 'Admins', value: 15, color: '#f59e0b' },
];

const MONTHLY_DATA = [
  { month: 'Jan', messages: 4200 },
  { month: 'Feb', messages: 5100 },
  { month: 'Mar', messages: 4800 },
  { month: 'Apr', messages: 6300 },
  { month: 'May', messages: 7100 },
  { month: 'Jun', messages: 6800 },
];

const MOCK_USERS: User[] = [
  { id: 'u1', name: 'Sarah Chen', email: 'sarah@company.com', role: 'admin', status: 'online', title: 'Engineering Lead', createdAt: '' },
  { id: 'u2', name: 'Marcus Johnson', email: 'marcus@company.com', role: 'member', status: 'online', title: 'Senior Developer', createdAt: '' },
  { id: 'u3', name: 'Elena Rodriguez', email: 'elena@company.com', role: 'member', status: 'away', title: 'Product Designer', createdAt: '' },
  { id: 'u4', name: 'David Park', email: 'david@company.com', role: 'member', status: 'offline', title: 'Backend Engineer', createdAt: '' },
  { id: 'u5', name: 'Aisha Patel', email: 'aisha@company.com', role: 'moderator', status: 'online', title: 'Project Manager', createdAt: '' },
  { id: 'u6', name: 'James Wilson', email: 'james@company.com', role: 'member', status: 'dnd', title: 'QA Engineer', createdAt: '' },
  { id: 'u7', name: 'Lisa Thompson', email: 'lisa@company.com', role: 'member', status: 'online', title: 'Frontend Developer', createdAt: '' },
  { id: 'u8', name: 'Omar Hassan', email: 'omar@company.com', role: 'member', status: 'away', title: 'DevOps Engineer', createdAt: '' },
];

// ═══════════════════════════════════════════════════════════
// ADMIN DASHBOARD
// ═══════════════════════════════════════════════════════════
const AdminDashboard: React.FC = () => {
  const chartTextColor = '#888';
  const gridColor = '#e5e7eb';

  return (
    <div className="flex-1 overflow-y-auto p-8 font-body">
      <div className="max-w-5xl">
        <h2 className="text-xl font-black text-gray-900 dark:text-gray-100 font-display mb-6">
          Admin Dashboard
        </h2>

        {/* Stats */}
        <div className="grid grid-cols-4 gap-3.5 mb-7">
          {STATS.map((s) => (
            <div key={s.label} className="bg-white dark:bg-surface-900 border border-subtle rounded-2xl p-5">
              <div className="flex justify-between items-start mb-3">
                <div
                  className="w-10 h-10 rounded-xl flex items-center justify-center"
                  style={{ backgroundColor: s.color + '12' }}
                >
                  <s.icon size={18} style={{ color: s.color }} />
                </div>
                <span className="text-xs font-bold text-emerald-500 bg-emerald-50 dark:bg-emerald-500/10 px-2 py-0.5 rounded-md">
                  {s.change}
                </span>
              </div>
              <div className="text-2xl font-black text-gray-900 dark:text-gray-100 font-display tracking-tight">{s.value}</div>
              <div className="text-xs text-gray-500 mt-0.5">{s.label}</div>
            </div>
          ))}
        </div>

        {/* Charts row */}
        <div className="grid grid-cols-[2fr_1fr] gap-3.5 mb-7">
          {/* Weekly activity */}
          <div className="bg-white dark:bg-surface-900 border border-subtle rounded-2xl p-5">
            <h3 className="font-bold text-sm text-gray-900 dark:text-gray-100 font-display mb-5">Weekly Activity</h3>
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={ACTIVITY_DATA}>
                <CartesianGrid strokeDasharray="3 3" stroke={gridColor} className="dark:opacity-20" />
                <XAxis dataKey="day" tick={{ fill: chartTextColor, fontSize: 11 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: chartTextColor, fontSize: 11 }} axisLine={false} tickLine={false} />
                <Tooltip
                  contentStyle={{
                    background: 'white', border: '1px solid #e5e7eb', borderRadius: 8, fontSize: 12,
                  }}
                />
                <Bar dataKey="messages" fill="#6247ea" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Role distribution */}
          <div className="bg-white dark:bg-surface-900 border border-subtle rounded-2xl p-5">
            <h3 className="font-bold text-sm text-gray-900 dark:text-gray-100 font-display mb-5">Users by Role</h3>
            <ResponsiveContainer width="100%" height={170}>
              <PieChart>
                <Pie data={ROLE_DATA} cx="50%" cy="50%" innerRadius={42} outerRadius={65} dataKey="value" paddingAngle={4}>
                  {ROLE_DATA.map((entry, i) => (
                    <Cell key={i} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ background: 'white', border: '1px solid #e5e7eb', borderRadius: 8, fontSize: 12 }} />
              </PieChart>
            </ResponsiveContainer>
            <div className="flex justify-center gap-4 mt-2">
              {ROLE_DATA.map((r) => (
                <div key={r.name} className="flex items-center gap-1.5">
                  <div className="w-2 h-2 rounded-full" style={{ backgroundColor: r.color }} />
                  <span className="text-[11px] text-gray-500">{r.name}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Monthly trends */}
        <div className="bg-white dark:bg-surface-900 border border-subtle rounded-2xl p-5 mb-7">
          <h3 className="font-bold text-sm text-gray-900 dark:text-gray-100 font-display mb-5">Monthly Trends</h3>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={MONTHLY_DATA}>
              <CartesianGrid strokeDasharray="3 3" stroke={gridColor} className="dark:opacity-20" />
              <XAxis dataKey="month" tick={{ fill: chartTextColor, fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: chartTextColor, fontSize: 11 }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{ background: 'white', border: '1px solid #e5e7eb', borderRadius: 8, fontSize: 12 }} />
              <Area type="monotone" dataKey="messages" stroke="#6247ea" fill="rgba(98,71,234,0.08)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* User management table */}
        <div className="bg-white dark:bg-surface-900 border border-subtle rounded-2xl p-5">
          <h3 className="font-bold text-sm text-gray-900 dark:text-gray-100 font-display mb-5">User Management</h3>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr>
                  {['User', 'Role', 'Status', 'Title'].map((h) => (
                    <th
                      key={h}
                      className="text-left px-4 py-2.5 text-[11px] font-bold uppercase tracking-wide text-gray-400 border-b border-subtle"
                    >
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {MOCK_USERS.map((u) => (
                  <tr key={u.id} className="hover:bg-surface-50 dark:hover:bg-surface-800/30 transition-colors">
                    <td className="px-4 py-3 border-b border-subtle/50">
                      <div className="flex items-center gap-2.5">
                        <Avatar user={u} size="sm" />
                        <div>
                          <div className="text-[13px] font-semibold text-gray-900 dark:text-gray-100">{u.name}</div>
                          <div className="text-[11px] text-gray-400">{u.email}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 border-b border-subtle/50">
                      <span
                        className={`text-[11px] font-semibold px-2.5 py-1 rounded-md ${
                          u.role === 'admin'
                            ? 'bg-amber-50 dark:bg-amber-500/10 text-amber-600 dark:text-amber-400'
                            : u.role === 'moderator'
                            ? 'bg-brand-50 dark:bg-brand-500/10 text-brand-600 dark:text-brand-400'
                            : 'bg-surface-100 dark:bg-surface-800 text-gray-500'
                        }`}
                      >
                        {u.role}
                      </span>
                    </td>
                    <td className="px-4 py-3 border-b border-subtle/50">
                      <div className="flex items-center gap-1.5">
                        <div
                          className={`w-1.5 h-1.5 rounded-full ${
                            u.status === 'online'
                              ? 'bg-emerald-500'
                              : u.status === 'away'
                              ? 'bg-amber-500'
                              : u.status === 'dnd'
                              ? 'bg-red-500'
                              : 'bg-gray-400'
                          }`}
                        />
                        <span className="text-xs text-gray-500 capitalize">{u.status}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 border-b border-subtle/50 text-[13px] text-gray-500">{u.title}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
