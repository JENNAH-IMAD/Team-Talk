import React, { useState } from 'react';
import { Edit2, Trash2, Smile, Reply, Bookmark, Check, X } from 'lucide-react';
import { Avatar } from '@/components/ui';
import { formatTime, cn } from '@/utils';
import type { Message, User } from '@/types';

interface MessageBubbleProps {
  message: Message;
  user: User;
  isOwn: boolean;
  onEdit?: (messageId: string, content: string) => void;
  onDelete?: (messageId: string) => void;
  onReply?: (messageId: string) => void;
}

export const MessageBubble: React.FC<MessageBubbleProps> = ({
  message,
  user,
  isOwn,
  onEdit,
  onDelete,
  onReply,
}) => {
  const [showActions, setShowActions] = useState(false);
  const [editing, setEditing] = useState(false);
  const [editText, setEditText] = useState(message.content);

  const handleSaveEdit = () => {
    if (editText.trim() && editText !== message.content) {
      onEdit?.(message.id, editText);
    }
    setEditing(false);
  };

  const renderContent = (text: string) => {
    return text.split(/(@\w+)/g).map((part, i) =>
      part.startsWith('@') ? (
        <span
          key={i}
          className="bg-brand-500/10 text-brand-500 dark:text-brand-300 px-1 rounded font-semibold"
        >
          {part}
        </span>
      ) : (
        <React.Fragment key={i}>{part}</React.Fragment>
      )
    );
  };

  return (
    <div
      onMouseEnter={() => setShowActions(true)}
      onMouseLeave={() => setShowActions(false)}
      className={cn(
        'group relative flex gap-3 px-5 py-1.5 transition-colors duration-100',
        showActions && 'bg-surface-50/60 dark:bg-surface-800/30'
      )}
    >
      <Avatar user={user} size="sm" showStatus={false} />

      <div className="flex-1 min-w-0">
        {/* Header */}
        <div className="flex items-baseline gap-2 mb-0.5">
          <span className="font-bold text-[13px] text-gray-900 dark:text-gray-100 font-body">
            {user.name}
          </span>
          <span className="text-[11px] text-gray-400 dark:text-gray-600">
            {formatTime(message.timestamp)}
          </span>
          {message.edited && (
            <span className="text-[10px] text-gray-400 dark:text-gray-600 italic">
              (edited)
            </span>
          )}
        </div>

        {/* Content */}
        {editing ? (
          <div className="flex items-center gap-2 mt-1">
            <input
              value={editText}
              onChange={(e) => setEditText(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSaveEdit()}
              className="flex-1 bg-surface-100 dark:bg-surface-800 border border-subtle rounded-lg px-3 py-1.5 text-sm text-gray-900 dark:text-gray-100 outline-none focus:border-brand-500"
              autoFocus
            />
            <button onClick={handleSaveEdit} className="p-1 text-emerald-500 hover:bg-emerald-50 dark:hover:bg-emerald-500/10 rounded">
              <Check size={16} />
            </button>
            <button onClick={() => { setEditing(false); setEditText(message.content); }} className="p-1 text-red-500 hover:bg-red-50 dark:hover:bg-red-500/10 rounded">
              <X size={16} />
            </button>
          </div>
        ) : (
          <div className="text-sm text-gray-800 dark:text-gray-200 leading-relaxed">
            {renderContent(message.content)}
          </div>
        )}

        {/* Reactions */}
        {message.reactions.length > 0 && (
          <div className="flex gap-1.5 mt-1.5">
            {message.reactions.map((reaction, i) => (
              <button
                key={i}
                className="flex items-center gap-1 bg-surface-100 dark:bg-surface-800 border border-subtle rounded-full px-2 py-0.5 text-xs hover:border-brand-500/50 transition-colors"
              >
                <span>{reaction.emoji}</span>
                <span className="font-semibold text-gray-500 dark:text-gray-400">
                  {reaction.users.length}
                </span>
              </button>
            ))}
          </div>
        )}

        {/* Thread indicator */}
        {message.threadCount > 0 && (
          <button className="flex items-center gap-1.5 mt-1.5 text-brand-500 text-xs font-semibold hover:underline">
            <Reply size={13} />
            {message.threadCount} {message.threadCount === 1 ? 'reply' : 'replies'}
          </button>
        )}
      </div>

      {/* Hover actions */}
      {showActions && !editing && (
        <div className="absolute -top-3 right-5 flex items-center bg-white dark:bg-surface-850 border border-subtle rounded-lg shadow-md p-0.5 animate-scale-in">
          {[
            { icon: Smile, label: 'React', onClick: () => {} },
            { icon: Reply, label: 'Reply', onClick: () => onReply?.(message.id) },
            ...(isOwn ? [{ icon: Edit2, label: 'Edit', onClick: () => setEditing(true) }] : []),
            ...(isOwn ? [{ icon: Trash2, label: 'Delete', onClick: () => onDelete?.(message.id), danger: true }] : []),
            { icon: Bookmark, label: 'Save', onClick: () => {} },
          ].map((action, i) => (
            <button
              key={i}
              onClick={action.onClick}
              title={action.label}
              className={cn(
                'p-1.5 rounded-md transition-colors',
                (action as { danger?: boolean }).danger
                  ? 'text-red-500 hover:bg-red-50 dark:hover:bg-red-500/10'
                  : 'text-gray-400 hover:bg-surface-100 dark:hover:bg-surface-800 hover:text-gray-600 dark:hover:text-gray-300'
              )}
            >
              <action.icon size={14} />
            </button>
          ))}
        </div>
      )}
    </div>
  );
};
