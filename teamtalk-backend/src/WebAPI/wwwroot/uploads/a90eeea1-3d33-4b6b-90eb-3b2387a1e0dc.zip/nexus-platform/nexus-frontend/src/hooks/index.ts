import { useEffect, useRef, useCallback, useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import type { TypedUseSelectorHook } from 'react-redux';
import type { RootState, AppDispatch } from '@/store';
import { signalRService } from '@/services/signalRService';
import { addMessage, setTyping } from '@/store/slices/chatSlice';
import { addNotification } from '@/store/slices/notificationSlice';
import type { Message, Notification, TypingEvent } from '@/types';

// ── Typed Redux Hooks ────────────────────────────────────────
export const useAppDispatch: () => AppDispatch = useDispatch;
export const useAppSelector: TypedUseSelectorHook<RootState> = useSelector;

// ── useAuth ──────────────────────────────────────────────────
export function useAuth() {
  const { user, isAuthenticated, isLoading, error } = useAppSelector(
    (state) => state.auth
  );
  return { user, isAuthenticated, isLoading, error };
}

// ── useSignalR ───────────────────────────────────────────────
export function useSignalR() {
  const dispatch = useAppDispatch();
  const { isAuthenticated } = useAuth();

  useEffect(() => {
    if (!isAuthenticated) return;

    signalRService.start().then(() => {
      signalRService.onMessageReceived((message: Message) => {
        dispatch(addMessage(message));
      });

      signalRService.onTyping((event: TypingEvent) => {
        dispatch(setTyping(event));
      });

      signalRService.onNotification((notification: unknown) => {
        dispatch(addNotification(notification as Notification));
      });
    });

    return () => {
      signalRService.offAll();
      signalRService.stop();
    };
  }, [isAuthenticated, dispatch]);

  const joinChannel = useCallback((channelId: string) => {
    signalRService.joinChannel(channelId);
  }, []);

  const leaveChannel = useCallback((channelId: string) => {
    signalRService.leaveChannel(channelId);
  }, []);

  const sendTyping = useCallback((channelId: string, isTyping: boolean) => {
    signalRService.sendTyping(channelId, isTyping);
  }, []);

  return { joinChannel, leaveChannel, sendTyping };
}

// ── useDebounce ──────────────────────────────────────────────
export function useDebounce<T>(value: T, delay: number): T {
  const [debouncedValue, setDebouncedValue] = useState<T>(value);

  useEffect(() => {
    const timer = setTimeout(() => setDebouncedValue(value), delay);
    return () => clearTimeout(timer);
  }, [value, delay]);

  return debouncedValue;
}

// ── useNotifications ─────────────────────────────────────────
export function useNotifications() {
  const { notifications, unreadCount } = useAppSelector(
    (state) => state.notifications
  );
  return { notifications, unreadCount };
}

// ── useClickOutside ──────────────────────────────────────────
export function useClickOutside(handler: () => void) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const listener = (event: MouseEvent | TouchEvent) => {
      if (!ref.current || ref.current.contains(event.target as Node)) return;
      handler();
    };
    document.addEventListener('mousedown', listener);
    document.addEventListener('touchstart', listener);
    return () => {
      document.removeEventListener('mousedown', listener);
      document.removeEventListener('touchstart', listener);
    };
  }, [handler]);

  return ref;
}

// ── useTheme ─────────────────────────────────────────────────
export function useTheme() {
  const [isDark, setIsDark] = useState(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('nexus_theme') === 'dark' ||
        (!localStorage.getItem('nexus_theme') && window.matchMedia('(prefers-color-scheme: dark)').matches);
    }
    return true;
  });

  useEffect(() => {
    const root = document.documentElement;
    if (isDark) {
      root.classList.add('dark');
      localStorage.setItem('nexus_theme', 'dark');
    } else {
      root.classList.remove('dark');
      localStorage.setItem('nexus_theme', 'light');
    }
  }, [isDark]);

  const toggle = useCallback(() => setIsDark((prev) => !prev), []);

  return { isDark, toggle };
}
