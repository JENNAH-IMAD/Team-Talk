import React from 'react';
import { MessageSquare, Users, Reply, Smile, Hash } from 'lucide-react';
import { Avatar } from '@/components/ui';
import { formatTime } from '@/utils';
import type { User } from '@/types';

const USERS: User[] = [
  { id: 'u1', name: 'Sarah Chen', email: '', role: 'admin', status: 'online', title: 'Engineering Lead', createdAt: '' },
  { id: 'u2', name: 'Marcus Johnson', email: '', role: 'member', status: 'online', title: 'Senior Developer', createdAt: '' },
  { id: 'u3', name: 'Elena Rodriguez', email: '', role: 'member', status: 'away', title: 'Product Designer', createdAt: '' },
  { id: 'u4', name: 'David Park', email: '', role: 'member', status: 'offline', title: 'Backend Engineer', createdAt: '' },
  { id: 'u5', name: 'Aisha Patel', email: '', role: 'moderator', status: 'online', title: 'Project Manager', createdAt: '' },
  { id: 'u7', name: 'Lisa Thompson', email: '', role: 'member', status: 'online', title: 'Frontend Developer', createdAt: '' },
];

const activities = [
  { id: 1, type: 'message', user: USERS[1], text: 'mentioned you in #general', time: Date.now() - 300_000 },
  { id: 2, type: 'team', user: USERS[4], text: 'added you to the Design team', time: Date.now() - 1_800_000 },
  { id: 3, type: 'reply', user: USERS[5], text: 'replied to your message in #frontend', time: Date.now() - 3_600_000 },
  { id: 4, type: 'reaction', user: USERS[2], text: 'reacted 🔥 to your message', time: Date.now() - 5_400_000 },
  { id: 5, type: 'channel', user: USERS[0], text: 'created a new channel #architecture', time: Date.now() - 7_200_000 },
  { id: 6, type: 'message', user: USERS[3], text: 'sent you a direct message', time: Date.now() - 9_000_000 },
];

const ActivityPage: React.FC = () => {
  return (
    <div className="flex-1 overflow-y-auto p-8">
      <div className="max-w-xl">
        <h2 className="text-xl font-black text-gray-900 dark:text-gray-100 font-display mb-6">Activity</h2>
        <div className="space-y-1.5">
          {activities.map((a) => (
            <div
              key={a.id}
              className="flex items-center gap-3.5 px-4 py-3.5 bg-white dark:bg-surface-900 border border-subtle rounded-xl cursor-pointer hover:shadow-sm transition-all"
            >
              <Avatar user={a.user} size="md" showStatus={false} />
              <div className="flex-1 min-w-0">
                <span className="text-sm text-gray-900 dark:text-gray-100">
                  <strong className="font-semibold">{a.user.name}</strong>{' '}
                  <span className="text-gray-500 dark:text-gray-400">{a.text}</span>
                </span>
              </div>
              <span className="text-xs text-gray-400 dark:text-gray-600 flex-shrink-0">{formatTime(a.time)}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ActivityPage;
