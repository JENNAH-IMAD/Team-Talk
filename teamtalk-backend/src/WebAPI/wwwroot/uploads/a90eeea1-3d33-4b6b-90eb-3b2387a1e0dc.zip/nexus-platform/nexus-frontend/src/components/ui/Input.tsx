import React, { forwardRef, useState } from 'react';
import { cn } from '@/utils';

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  icon?: React.ReactNode;
  rightIcon?: React.ReactNode;
}

export const Input = forwardRef<HTMLInputElement, InputProps>(
  ({ label, error, icon, rightIcon, className, ...props }, ref) => {
    const [focused, setFocused] = useState(false);

    return (
      <div className="mb-4">
        {label && (
          <label className="block text-xs font-semibold text-gray-500 dark:text-gray-400 mb-1.5 uppercase tracking-wide font-body">
            {label}
          </label>
        )}
        <div
          className={cn(
            'flex items-center gap-2 rounded-xl px-3.5',
            'bg-surface-100 dark:bg-surface-850',
            'border-[1.5px] transition-colors duration-150',
            focused
              ? 'border-brand-500 ring-2 ring-brand-500/10'
              : error
              ? 'border-red-400'
              : 'border-transparent',
            className
          )}
        >
          {icon && (
            <span className="text-gray-400 dark:text-gray-500 flex-shrink-0">
              {icon}
            </span>
          )}
          <input
            ref={ref}
            onFocus={(e) => {
              setFocused(true);
              props.onFocus?.(e);
            }}
            onBlur={(e) => {
              setFocused(false);
              props.onBlur?.(e);
            }}
            className={cn(
              'w-full py-2.5 bg-transparent outline-none text-sm font-body',
              'text-gray-900 dark:text-gray-100',
              'placeholder:text-gray-400 dark:placeholder:text-gray-600'
            )}
            {...props}
          />
          {rightIcon && (
            <span className="text-gray-400 dark:text-gray-500 flex-shrink-0 cursor-pointer">
              {rightIcon}
            </span>
          )}
        </div>
        {error && (
          <p className="mt-1 text-xs text-red-500 font-medium">{error}</p>
        )}
      </div>
    );
  }
);

Input.displayName = 'Input';
