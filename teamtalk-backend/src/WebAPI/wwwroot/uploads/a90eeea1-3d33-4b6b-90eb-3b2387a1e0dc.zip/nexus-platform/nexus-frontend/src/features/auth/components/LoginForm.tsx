import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Mail, Lock, Eye, EyeOff } from 'lucide-react';
import { useAppDispatch, useAuth } from '@/hooks';
import { loginUser, clearError } from '@/store/slices/authSlice';
import { Button, Input } from '@/components/ui';

const loginSchema = z.object({
  email: z.string().min(1, 'Email is required').email('Invalid email format'),
  password: z.string().min(6, 'Minimum 6 characters'),
});

type LoginFormData = z.infer<typeof loginSchema>;

export const LoginForm: React.FC = () => {
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const { isLoading, error, isAuthenticated } = useAuth();
  const [showPassword, setShowPassword] = useState(false);

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<LoginFormData>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: 'sarah@company.com',
      password: 'password123',
    },
  });

  // Navigate to dashboard when authenticated
  useEffect(() => {
    if (isAuthenticated) {
      navigate('/dashboard', { replace: true });
    }
  }, [isAuthenticated, navigate]);

  const onSubmit = (data: LoginFormData) => {
    dispatch(clearError());
    dispatch(loginUser(data));
  };

  return (
    <div>
      <h2 className="text-2xl font-black text-gray-900 dark:text-gray-100 font-display tracking-tight mb-1">
        Welcome back
      </h2>
      <p className="text-sm text-gray-500 dark:text-gray-400 mb-8">
        Sign in to your workspace
      </p>

      {error && (
        <div className="mb-4 p-3 rounded-xl bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/20 text-red-600 dark:text-red-400 text-sm">
          {error}
        </div>
      )}

      <div>
        <Input
          label="Email"
          placeholder="you@company.com"
          icon={<Mail size={16} />}
          error={errors.email?.message}
          {...register('email')}
        />

        <Input
          label="Password"
          type={showPassword ? 'text' : 'password'}
          placeholder="••••••••"
          icon={<Lock size={16} />}
          rightIcon={
            <button type="button" onClick={() => setShowPassword(!showPassword)}>
              {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
            </button>
          }
          error={errors.password?.message}
          {...register('password')}
        />

        <div className="flex items-center justify-between mb-6 -mt-1">
          <label className="flex items-center gap-2 cursor-pointer">
            <input type="checkbox" className="accent-brand-500 rounded" />
            <span className="text-xs text-gray-500">Remember me</span>
          </label>
          <button type="button" className="text-xs text-brand-500 font-semibold hover:underline">
            Forgot password?
          </button>
        </div>

        <Button
          onClick={handleSubmit(onSubmit)}
          isLoading={isLoading}
          className="w-full justify-center py-2.5 text-sm"
        >
          Sign in
        </Button>
      </div>

      <p className="text-center text-[11px] text-gray-400 mt-6">
        Demo credentials: sarah@company.com / password123
      </p>
    </div>
  );
};
