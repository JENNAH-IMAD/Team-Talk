import * as signalR from '@microsoft/signalr';
import { storage } from '@/utils';
import type { Message, TypingEvent } from '@/types';

const HUB_URL = import.meta.env.VITE_SIGNALR_URL || 'http://localhost:5001/hubs/chat';

class SignalRService {
  private connection: signalR.HubConnection | null = null;

  async start(): Promise<void> {
    const token = storage.getToken();
    if (!token) return;

    this.connection = new signalR.HubConnectionBuilder()
      .withUrl(HUB_URL, { accessTokenFactory: () => token })
      .withAutomaticReconnect([0, 2000, 5000, 10000, 30000])
      .configureLogging(signalR.LogLevel.Warning)
      .build();

    this.connection.onreconnecting(() => console.log('[SignalR] Reconnecting...'));
    this.connection.onreconnected(() => console.log('[SignalR] Reconnected'));
    this.connection.onclose(() => console.log('[SignalR] Connection closed'));

    try {
      await this.connection.start();
      console.log('[SignalR] Connected');
    } catch (err) {
      console.error('[SignalR] Connection failed:', err);
    }
  }

  async stop(): Promise<void> {
    if (this.connection) { await this.connection.stop(); this.connection = null; }
  }

  async joinChannel(channelId: string): Promise<void> {
    if (this.connection?.state === signalR.HubConnectionState.Connected)
      await this.connection.invoke('JoinChannel', channelId);
  }

  async leaveChannel(channelId: string): Promise<void> {
    if (this.connection?.state === signalR.HubConnectionState.Connected)
      await this.connection.invoke('LeaveChannel', channelId);
  }

  async sendMessage(channelId: string, content: string): Promise<void> {
    if (this.connection?.state === signalR.HubConnectionState.Connected)
      await this.connection.invoke('SendMessage', channelId, content);
  }

  async sendTyping(channelId: string, isTyping: boolean): Promise<void> {
    if (this.connection?.state === signalR.HubConnectionState.Connected)
      await this.connection.invoke('SendTyping', channelId, isTyping);
  }

  onMessageReceived(callback: (message: Message) => void): void {
    this.connection?.on('ReceiveMessage', callback);
  }
  onMessageEdited(callback: (message: Message) => void): void {
    this.connection?.on('MessageEdited', callback);
  }
  onMessageDeleted(callback: (messageId: string, channelId: string) => void): void {
    this.connection?.on('MessageDeleted', callback);
  }
  onTyping(callback: (event: TypingEvent) => void): void {
    this.connection?.on('UserTyping', callback);
  }
  onUserStatusChanged(callback: (userId: string, status: string) => void): void {
    this.connection?.on('UserStatusChanged', callback);
  }
  onNotification(callback: (notification: unknown) => void): void {
    this.connection?.on('ReceiveNotification', callback);
  }

  offAll(): void {
    if (!this.connection) return;
    ['ReceiveMessage', 'MessageEdited', 'MessageDeleted', 'UserTyping', 'UserStatusChanged', 'ReceiveNotification']
      .forEach(e => this.connection!.off(e));
  }
}

export const signalRService = new SignalRService();
