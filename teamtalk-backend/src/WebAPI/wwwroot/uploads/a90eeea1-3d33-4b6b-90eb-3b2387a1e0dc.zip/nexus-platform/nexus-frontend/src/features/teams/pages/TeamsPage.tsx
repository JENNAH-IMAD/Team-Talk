import React, { useState } from 'react';
import { Search, Plus, Edit2, Trash2, UserPlus } from 'lucide-react';
import { useAppDispatch, useAppSelector } from '@/hooks';
import { createTeam, updateTeam, deleteTeam } from '@/store/slices/teamSlice';
import { Avatar, Button, Input, Modal } from '@/components/ui';
import type { User } from '@/types';

const USERS: Record<string, User> = {
  u1: { id: 'u1', name: 'Sarah Chen', email: 'sarah@company.com', role: 'admin', status: 'online', title: 'Engineering Lead', createdAt: '' },
  u2: { id: 'u2', name: 'Marcus Johnson', email: 'marcus@company.com', role: 'member', status: 'online', title: 'Senior Developer', createdAt: '' },
  u3: { id: 'u3', name: 'Elena Rodriguez', email: 'elena@company.com', role: 'member', status: 'away', title: 'Product Designer', createdAt: '' },
  u4: { id: 'u4', name: 'David Park', email: 'david@company.com', role: 'member', status: 'offline', title: 'Backend Engineer', createdAt: '' },
  u5: { id: 'u5', name: 'Aisha Patel', email: 'aisha@company.com', role: 'moderator', status: 'online', title: 'Project Manager', createdAt: '' },
  u7: { id: 'u7', name: 'Lisa Thompson', email: 'lisa@company.com', role: 'member', status: 'online', title: 'Frontend Developer', createdAt: '' },
  u8: { id: 'u8', name: 'Omar Hassan', email: 'omar@company.com', role: 'member', status: 'away', title: 'DevOps Engineer', createdAt: '' },
};

const TeamsPage: React.FC = () => {
  const dispatch = useAppDispatch();
  const teams = useAppSelector((s) => s.teams.teams);
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formName, setFormName] = useState('');
  const [formDesc, setFormDesc] = useState('');
  const [search, setSearch] = useState('');

  const openCreate = () => {
    setEditingId(null);
    setFormName('');
    setFormDesc('');
    setShowModal(true);
  };

  const openEdit = (team: typeof teams[0]) => {
    setEditingId(team.id);
    setFormName(team.name);
    setFormDesc(team.description);
    setShowModal(true);
  };

  const handleSave = () => {
    if (!formName.trim()) return;
    if (editingId) {
      dispatch(updateTeam({ id: editingId, name: formName, description: formDesc }));
    } else {
      dispatch(createTeam({ name: formName, description: formDesc }));
    }
    setShowModal(false);
  };

  const handleDelete = (id: string) => {
    dispatch(deleteTeam(id));
  };

  const filtered = teams.filter((t) => t.name.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="flex-1 overflow-y-auto p-8">
      <div className="max-w-3xl">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-xl font-black text-gray-900 dark:text-gray-100 font-display">Teams</h2>
            <p className="text-sm text-gray-500 mt-0.5">{teams.length} teams in workspace</p>
          </div>
          <Button onClick={openCreate} icon={<Plus size={14} />}>New Team</Button>
        </div>

        {/* Search */}
        <div className="flex items-center gap-2 bg-surface-100 dark:bg-surface-850 rounded-xl px-3.5 py-2 mb-5 border border-subtle">
          <Search size={15} className="text-gray-400" />
          <input
            placeholder="Search teams..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="bg-transparent border-none outline-none text-sm text-gray-900 dark:text-gray-100 w-full placeholder:text-gray-400 font-body"
          />
        </div>

        {/* Team cards */}
        <div className="space-y-3">
          {filtered.map((team) => {
            const members = team.members.map((id) => USERS[id]).filter(Boolean);
            return (
              <div
                key={team.id}
                className="bg-white dark:bg-surface-900 border border-subtle rounded-2xl p-5 transition-all hover:shadow-sm"
              >
                <div className="flex items-center gap-3.5 mb-4">
                  <div
                    className="w-11 h-11 rounded-xl flex items-center justify-center text-xl"
                    style={{ backgroundColor: team.color + '18' }}
                  >
                    {team.icon}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-bold text-[15px] text-gray-900 dark:text-gray-100 font-display">{team.name}</div>
                    <div className="text-[13px] text-gray-500">{team.description}</div>
                  </div>
                  <div className="flex gap-1.5">
                    <Button variant="ghost" size="sm" onClick={() => openEdit(team)} icon={<Edit2 size={14} />} />
                    <Button variant="ghost" size="sm" onClick={() => handleDelete(team.id)} icon={<Trash2 size={14} />} />
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="flex -space-x-2">
                    {members.slice(0, 5).map((m) => (
                      <Avatar key={m.id} user={m} size="xs" showStatus={false} className="ring-2 ring-white dark:ring-surface-900" />
                    ))}
                  </div>
                  <span className="text-xs text-gray-500">{members.length} members</span>
                  <div className="flex-1" />
                  <Button variant="secondary" size="sm" icon={<UserPlus size={13} />}>
                    Add Member
                  </Button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Modal */}
      <Modal isOpen={showModal} onClose={() => setShowModal(false)} title={editingId ? 'Edit Team' : 'Create Team'}>
        <Input label="Team Name" placeholder="e.g. Engineering" value={formName} onChange={(e) => setFormName(e.target.value)} />
        <Input label="Description" placeholder="What is this team about?" value={formDesc} onChange={(e) => setFormDesc(e.target.value)} />
        <div className="flex justify-end gap-2 mt-2">
          <Button variant="secondary" onClick={() => setShowModal(false)}>Cancel</Button>
          <Button onClick={handleSave}>{editingId ? 'Save Changes' : 'Create Team'}</Button>
        </div>
      </Modal>
    </div>
  );
};

export default TeamsPage;
