using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.SignalR;
using NexusPlatform.Application.DTOs.Chat;
using NexusPlatform.Application.Interfaces;

namespace NexusPlatform.WebAPI.Hubs;

[Authorize]
public class ChatHub : Hub
{
    private readonly IChatService _chatService;
    private readonly INotificationService _notificationService;

    public ChatHub(IChatService chatService, INotificationService notificationService)
    {
        _chatService = chatService;
        _notificationService = notificationService;
    }

    private Guid GetUserId() => Guid.Parse(Context.User!.FindFirst(ClaimTypes.NameIdentifier)!.Value);

    public override async Task OnConnectedAsync()
    {
        await base.OnConnectedAsync();
    }

    public override async Task OnDisconnectedAsync(Exception? exception)
    {
        await base.OnDisconnectedAsync(exception);
    }

    public async Task JoinChannel(string channelId)
    {
        await Groups.AddToGroupAsync(Context.ConnectionId, channelId);
    }

    public async Task LeaveChannel(string channelId)
    {
        await Groups.RemoveFromGroupAsync(Context.ConnectionId, channelId);
    }

    public async Task SendMessage(string channelId, string content)
    {
        var userId = GetUserId();
        var request = new SendMessageRequest { Content = content };
        var message = await _chatService.SendMessageAsync(Guid.Parse(channelId), userId, request);

        await Clients.Group(channelId).SendAsync("ReceiveMessage", message);
    }

    public async Task SendTyping(string channelId, bool isTyping)
    {
        var userId = GetUserId();
        await Clients.OthersInGroup(channelId).SendAsync("UserTyping", new
        {
            ChannelId = channelId,
            UserId = userId.ToString(),
            IsTyping = isTyping
        });
    }

    public async Task EditMessage(string channelId, string messageId, string content)
    {
        var userId = GetUserId();
        var message = await _chatService.EditMessageAsync(Guid.Parse(messageId), userId, new EditMessageRequest { Content = content });
        await Clients.Group(channelId).SendAsync("MessageEdited", message);
    }

    public async Task DeleteMessage(string channelId, string messageId)
    {
        var userId = GetUserId();
        await _chatService.DeleteMessageAsync(Guid.Parse(messageId), userId);
        await Clients.Group(channelId).SendAsync("MessageDeleted", messageId, channelId);
    }
}
