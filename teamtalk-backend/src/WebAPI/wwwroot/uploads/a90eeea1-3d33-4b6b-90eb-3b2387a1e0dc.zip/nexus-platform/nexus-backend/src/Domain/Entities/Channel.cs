namespace NexusPlatform.Domain.Entities;

public class Channel : BaseEntity
{
    public string Name { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public Guid TeamId { get; set; }
    public bool IsPrivate { get; set; } = false;
    public DateTime? LastMessageAt { get; set; }

    // Navigation
    public Team Team { get; set; } = null!;
    public ICollection<Message> Messages { get; set; } = new List<Message>();
}
