using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NexusPlatform.Application.DTOs.Auth;
using NexusPlatform.Application.DTOs.Team;
using NexusPlatform.Application.DTOs.Channel;
using NexusPlatform.Application.DTOs.Chat;
using NexusPlatform.Application.Interfaces;

namespace NexusPlatform.WebAPI.Controllers;

[ApiController]
[Route("api/[controller]")]
public abstract class BaseController : ControllerBase
{
    protected Guid GetUserId() => Guid.Parse(User.FindFirst(ClaimTypes.NameIdentifier)!.Value);
    protected string GetUserRole() => User.FindFirst(ClaimTypes.Role)!.Value;
}

// ═══════════════════════════════════════════════════════════
// AUTH CONTROLLER
// ═══════════════════════════════════════════════════════════
[Route("api/auth")]
public class AuthController : BaseController
{
    private readonly IAuthService _authService;
    public AuthController(IAuthService authService) { _authService = authService; }

    [HttpPost("login")]
    public async Task<ActionResult<AuthResponse>> Login([FromBody] LoginRequest request)
    {
        var response = await _authService.LoginAsync(request);
        return Ok(response);
    }

    [HttpPost("register")]
    public async Task<ActionResult<AuthResponse>> Register([FromBody] RegisterRequest request)
    {
        var response = await _authService.RegisterAsync(request);
        return CreatedAtAction(nameof(GetMe), response);
    }

    [HttpPost("refresh")]
    public async Task<ActionResult<AuthResponse>> RefreshToken([FromBody] RefreshTokenRequest request)
    {
        var response = await _authService.RefreshTokenAsync(request.RefreshToken);
        return Ok(response);
    }

    [Authorize]
    [HttpGet("me")]
    public async Task<ActionResult<UserDto>> GetMe()
    {
        var user = await _authService.GetCurrentUserAsync(GetUserId());
        return Ok(user);
    }

    [Authorize]
    [HttpPost("logout")]
    public async Task<IActionResult> Logout()
    {
        await _authService.LogoutAsync(GetUserId());
        return NoContent();
    }
}

// ═══════════════════════════════════════════════════════════
// USERS CONTROLLER
// ═══════════════════════════════════════════════════════════
[Authorize]
[Route("api/users")]
public class UsersController : BaseController
{
    private readonly IUserService _userService;
    public UsersController(IUserService userService) { _userService = userService; }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<UserDto>>> GetAll()
    {
        return Ok(await _userService.GetAllUsersAsync());
    }

    [HttpGet("{id:guid}")]
    public async Task<ActionResult<UserDto>> GetById(Guid id)
    {
        var user = await _userService.GetUserByIdAsync(id);
        return user == null ? NotFound() : Ok(user);
    }

    [HttpGet("search")]
    public async Task<ActionResult<IEnumerable<UserDto>>> Search([FromQuery] string q, [FromQuery] int page = 1)
    {
        return Ok(await _userService.SearchUsersAsync(q, page));
    }

    [HttpPut("status")]
    public async Task<IActionResult> UpdateStatus([FromBody] UpdateStatusRequest request)
    {
        await _userService.UpdateUserStatusAsync(GetUserId(), request.Status);
        return NoContent();
    }
}

public class UpdateStatusRequest { public string Status { get; set; } = string.Empty; }

// ═══════════════════════════════════════════════════════════
// TEAMS CONTROLLER
// ═══════════════════════════════════════════════════════════
[Authorize]
[Route("api/teams")]
public class TeamsController : BaseController
{
    private readonly ITeamService _teamService;
    public TeamsController(ITeamService teamService) { _teamService = teamService; }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<TeamDto>>> GetMyTeams()
    {
        return Ok(await _teamService.GetUserTeamsAsync(GetUserId()));
    }

    [HttpGet("{id:guid}")]
    public async Task<ActionResult<TeamDto>> GetById(Guid id)
    {
        var team = await _teamService.GetTeamByIdAsync(id);
        return team == null ? NotFound() : Ok(team);
    }

    [HttpPost]
    public async Task<ActionResult<TeamDto>> Create([FromBody] CreateTeamRequest request)
    {
        var team = await _teamService.CreateTeamAsync(request, GetUserId());
        return CreatedAtAction(nameof(GetById), new { id = team.Id }, team);
    }

    [HttpPut("{id:guid}")]
    public async Task<ActionResult<TeamDto>> Update(Guid id, [FromBody] UpdateTeamRequest request)
    {
        return Ok(await _teamService.UpdateTeamAsync(id, request));
    }

    [HttpDelete("{id:guid}")]
    [Authorize(Roles = "Admin,Manager")]
    public async Task<IActionResult> Delete(Guid id)
    {
        await _teamService.DeleteTeamAsync(id);
        return NoContent();
    }

    [HttpPost("{teamId:guid}/members")]
    public async Task<IActionResult> AddMember(Guid teamId, [FromBody] AddTeamMemberRequest request)
    {
        await _teamService.AddMemberAsync(teamId, request.UserId);
        return NoContent();
    }

    [HttpDelete("{teamId:guid}/members/{userId:guid}")]
    public async Task<IActionResult> RemoveMember(Guid teamId, Guid userId)
    {
        await _teamService.RemoveMemberAsync(teamId, userId);
        return NoContent();
    }
}

// ═══════════════════════════════════════════════════════════
// CHANNELS CONTROLLER
// ═══════════════════════════════════════════════════════════
[Authorize]
[Route("api/teams/{teamId:guid}/channels")]
public class ChannelsController : BaseController
{
    private readonly IChannelService _channelService;
    public ChannelsController(IChannelService channelService) { _channelService = channelService; }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<ChannelDto>>> GetTeamChannels(Guid teamId)
    {
        return Ok(await _channelService.GetTeamChannelsAsync(teamId));
    }

    [HttpPost]
    public async Task<ActionResult<ChannelDto>> Create(Guid teamId, [FromBody] CreateChannelRequest request)
    {
        var channel = await _channelService.CreateChannelAsync(teamId, request);
        return Created($"/api/channels/{channel.Id}", channel);
    }

    [HttpDelete("{channelId:guid}")]
    public async Task<IActionResult> Delete(Guid channelId)
    {
        await _channelService.DeleteChannelAsync(channelId);
        return NoContent();
    }
}

// ═══════════════════════════════════════════════════════════
// MESSAGES CONTROLLER
// ═══════════════════════════════════════════════════════════
[Authorize]
[Route("api/channels/{channelId:guid}/messages")]
public class MessagesController : BaseController
{
    private readonly IChatService _chatService;
    public MessagesController(IChatService chatService) { _chatService = chatService; }

    [HttpGet]
    public async Task<ActionResult<PaginatedResponse<MessageDto>>> GetMessages(Guid channelId, [FromQuery] int page = 1, [FromQuery] int pageSize = 50)
    {
        return Ok(await _chatService.GetMessagesAsync(channelId, page, pageSize));
    }

    [HttpPost]
    public async Task<ActionResult<MessageDto>> SendMessage(Guid channelId, [FromBody] SendMessageRequest request)
    {
        var message = await _chatService.SendMessageAsync(channelId, GetUserId(), request);
        return Created($"/api/channels/{channelId}/messages/{message.Id}", message);
    }

    [HttpPut("{messageId:guid}")]
    public async Task<ActionResult<MessageDto>> EditMessage(Guid channelId, Guid messageId, [FromBody] EditMessageRequest request)
    {
        return Ok(await _chatService.EditMessageAsync(messageId, GetUserId(), request));
    }

    [HttpDelete("{messageId:guid}")]
    public async Task<IActionResult> DeleteMessage(Guid channelId, Guid messageId)
    {
        await _chatService.DeleteMessageAsync(messageId, GetUserId());
        return NoContent();
    }
}

// ═══════════════════════════════════════════════════════════
// NOTIFICATIONS CONTROLLER
// ═══════════════════════════════════════════════════════════
[Authorize]
[Route("api/notifications")]
public class NotificationsController : BaseController
{
    private readonly INotificationService _notificationService;
    public NotificationsController(INotificationService notificationService) { _notificationService = notificationService; }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<NotificationDto>>> Get([FromQuery] int page = 1)
    {
        return Ok(await _notificationService.GetNotificationsAsync(GetUserId(), page));
    }

    [HttpGet("unread-count")]
    public async Task<ActionResult<int>> GetUnreadCount()
    {
        return Ok(await _notificationService.GetUnreadCountAsync(GetUserId()));
    }

    [HttpPut("{id:guid}/read")]
    public async Task<IActionResult> MarkAsRead(Guid id)
    {
        await _notificationService.MarkAsReadAsync(id, GetUserId());
        return NoContent();
    }

    [HttpPut("read-all")]
    public async Task<IActionResult> MarkAllAsRead()
    {
        await _notificationService.MarkAllAsReadAsync(GetUserId());
        return NoContent();
    }
}
